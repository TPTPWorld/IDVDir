
public class Order {

  /*

  given a graph with N nodes and E edges
  all nodes have depths, these are the ranks
  
  If an edge spans a node of more than one rank, break edge
   into multiple edges, each having the length of rank = 1

   

  */


  public Order (IDGraph g) {

  }

}
